<?php
	return array(
	'THE MAIN CONTENTS ARE AS FOLLOWS'=>'%sThe main contents are as follows:%s%s',
	'THE MAIN CONTENT'=>'The main content:%s',
	'EMAIL NOTIFICATION OF FAILURE THE OTHER PARTY IS NOT SET EFFECTIVE EMAIL'=>'Email notification of failure, the other party is not set effective email!',
	'SMS NOTIFICATION OF FAILURE THE OTHER PARTY IS NOT SET EFFECTIVE PHONE'=>'SMS send failure, the other party is not set effective phone number!',
	'SMS SEND FAILS AN ERROR CODE PLEASE CONTACT THE ADMINISTRATOR CONFIRMATION MESSAGE INTERFACE CONFIGURATION'=>'SMS send fails, an error code:%sPlease contact the administrator confirmation message interface configuration',
	'ADD COMMENTS SUCCESS'=>'Add comments success!',
	'ADD COMMENTS FAILED'=>'Add comments failed!',
	'PARAMETER ERROR'=>'Add comments failed!',
	'MODIFY COMMENTS SUCCESS'=>'Modify comments success!',
	'MODIFY COMMENTS FAILED'=>'Modify comments failed!',
	'33 WAS REMOVED SUCCESSFULLY'=>'33 was removed successfully!',
	'DELETE FAILED PLEASE CONTACT YOUR ADMINISTRATOR'=>'Delete failed!Please contact your administrator!',
	'TO_DISTRIBUTE_THE_CLUES_TO_INFORM'=>'Notice:',
	'STAND_INSIDE_LETTER'=>'Stand inside letter',
	'NOTE'=>'SMS',
	'EMAIL'=>'mail',
	);