<?php
return array(
	'ADD_FAILURE_PARTS_ACCESSORIES'=>'Add failure parts accessories',
	'ADD_ATTACHMENTS_FAIL'=>'Add attachments fail',
	'ADD_ATTACHMENTS_SUCCESS'=>'Add attachments successfully!',
	'PARAMETER_ERROR'=>'Parameter error',
	'YOU_HAVE_NO_RIGHT_TO_DELETE_THE_ATTACHMENT'=>'You have no right to delete the attachment!',
	'OPERATION_IS_SUCCESSFUL'=>'Operation is successful!',
	'FILE_NO_MORE_THAN_20MB'=>"No more than 20 MB file's total size",	
	'ALLOWED_FILE_TYPES'	   =>	'Allow the type:',
	'ADD_AN_ATTACHMENT'	   =>	'Add an attachment',


);

